<?php

define('KAREL_PROBLEM_NUMBER', 5);
include('../template.php');
