<?php

define('KAREL_PROBLEM_NUMBER', 2);
include('../template.php');
