<?php

define('KAREL_PROBLEM_NUMBER', 4);
include('../template.php');
