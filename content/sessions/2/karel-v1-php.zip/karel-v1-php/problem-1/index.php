<?php

define('KAREL_PROBLEM_NUMBER', 1);
include('../template.php');
