<?php
// Your solution goes here!
// For example:
// 
// move();
// move();
// turnLeft();
// 

?>