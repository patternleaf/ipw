<?php

define('KAREL_PROBLEM_NUMBER', 3);
include('../template.php');
