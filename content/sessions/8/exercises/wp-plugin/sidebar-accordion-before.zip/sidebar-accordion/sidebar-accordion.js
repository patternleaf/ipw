(function($) {
    console.log('hi there');
})(jQuery);
